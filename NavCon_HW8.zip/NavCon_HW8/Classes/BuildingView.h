//
//  BuildingView.h
//  NavCon_HW8
//
//  Created by SEI-HYONG PARK on 7/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BuildingController;

@interface BuildingView : UIView {
	BuildingController *controller;
	UIButton *button;
}

-(id) initWithFrame: (CGRect) frame controller: (BuildingController *) c;

@end
