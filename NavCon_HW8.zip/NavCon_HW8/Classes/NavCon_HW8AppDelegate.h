//
//  NavCon_HW8AppDelegate.h
//  NavCon_HW8
//
//  Created by SEI-HYONG PARK on 7/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BuildingController;

@interface NavCon_HW8AppDelegate : NSObject <UIApplicationDelegate> {
	NSArray *names;
	NSDictionary *building_pictures;
	NSDictionary *information;
	UINavigationController *controller;
	NSMutableArray *a;
    UIWindow *window;
}

-(void) nextBuilding;
-(void) moreInfo: (BuildingController *) bc;

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

