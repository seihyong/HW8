//
//  BuildingView.m
//  NavCon_HW8
//
//  Created by SEI-HYONG PARK on 7/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BuildingView.h"
#import "BuildingController.h"

@implementation BuildingView

-(void) moreInfo{
	[controller moreInfo];
}

- (id)initWithFrame:(CGRect)frame controller: (BuildingController *) c {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
		controller = c;
		self.backgroundColor = [UIColor whiteColor];
		
		self.contentMode = UIViewContentModeRedraw;
		
		button = [UIButton buttonWithType: UIButtonTypeRoundedRect];
		[button retain];
		
		CGSize	s = self.bounds.size;
		self.bounds = CGRectMake(-s.width/2,-s.height/2,s.width,s.height);
		
		NSString *title = @"More info";
		[button setTitle: title forState: UIControlStateNormal];
		s = [title sizeWithFont: button.titleLabel.font];
		
		button.frame = CGRectMake(0,0,s.width+20,s.height+10);
		button.center = CGPointZero;
		
		[button addTarget: self
				   action: @selector(moreInfo)
		 forControlEvents: UIControlEventTouchUpInside];
		
		[self addSubview: button];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
	[button release];
    [super dealloc];
}


@end
