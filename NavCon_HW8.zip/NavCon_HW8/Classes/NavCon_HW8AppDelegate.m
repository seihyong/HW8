//
//  NavCon_HW8AppDelegate.m
//  NavCon_HW8
//
//  Created by SEI-HYONG PARK on 7/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "NavCon_HW8AppDelegate.h"
#import	"BuildingController.h"
#import	"InfoController.h"

@implementation NavCon_HW8AppDelegate
@synthesize window;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
    // Override point for customization after application launch.
	// From http://www.rockrose.com/residential/property/
    names = [NSArray	arrayWithObjects:
			 @"200 Water Street",
			 @"22 River Terrace",
			 @"41 River Terrace",
			 @"666 Greenwich Street",
			 @"100 Jane Street",
			 @"410 West 53rd Street",
			 nil
			 ];
	[names retain];
	
	information = [NSDictionary dictionaryWithObjectsAndKeys:
				   @"Stunning city and waterfront view",@"200 Water Street",
				   @"27 story luxury rental at pulse of Battery Park City",@"22 River Terrace",
				   @"Soaring 42 stories above Hudson River",@"41 River Terrace",
				   @"Landmark treasure that has defined West Village style",@"666 Greenwich Street",
				   @"Located on a cobblestone street in Meatpacking",@"100 Jane Street",
				   @"Luxury city living in a vital and energized neighborhood",@"410 West 53rd Street",
				   nil
				   ];
	[information retain];
	
	
	//test test test test test 
	building_pictures = [NSDictionary dictionaryWithObjectsAndKeys:
				   @"200water.jpg",@"200 Water Street",
				   @"22river.jpg",@"22 River Terrace",
				   @"41river.jpg",@"41 River Terrace",
				   @"666greenwich.jpg",@"666 Greenwich Street",
				   @"100jane.jpg",@"100 Jane Street",
				   @"410w53rd.jpg",@"410 West 53rd Street",
				   nil
				   ];
	[building_pictures retain];
	//test test test test test 
	
	
	
	a = [[NSMutableArray alloc] init];
	[a addObject: [[BuildingController alloc]
				   initWithTitle: [names objectAtIndex:0]
				   northernNeighbor: names.count >1
				   ]];
	
	//Put the first station into the navigation controller
	controller = [[UINavigationController alloc]
				  initWithRootViewController: [a objectAtIndex: 0]];
	
	//Put the navigation controller into the window
	CGRect f = [UIScreen mainScreen].bounds;
	window = [[UIWindow alloc] initWithFrame: f];
	[window addSubview: controller.view];
				   
    [self.window makeKeyAndVisible];
    
    return YES;
}


-(void) nextBuilding{
	NSUInteger i = controller.viewControllers.count;
	if (i == names.count){
		//All building already pushed
		return;
	}
	
	if (a.count <= i){
		//New building pushed for the first time
		[a addObject: [[BuildingController alloc]
					   initWithTitle: [names objectAtIndex: i]
					   northernNeighbor: i < names.count - 1
					   ]];
	}
	
	[controller pushViewController: [a objectAtIndex: i] animated: YES];
}

-(void) moreInfo: (BuildingController *) bc{
	UIViewController *c = [[InfoController alloc]
						   initWithTitle: bc.title
						   information: [information objectForKey: bc.title]
	//test
						   building_pictures: [building_pictures objectForKey: bc.title]];
	//test
	c = [[UINavigationController alloc] initWithRootViewController: c];
	[bc presentModalViewController:c animated:YES];
}


- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}


- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
    [window release];
	
	for (BuildingController *c in a){
		[c release];
	}
	[a release];
	[information release];
	[names release];
    [super dealloc];
}


@end
