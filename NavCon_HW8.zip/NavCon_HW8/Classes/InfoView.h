//
//  InfoView.h
//  NavCon_HW8
//
//  Created by SEI-HYONG PARK on 7/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface InfoView : UIView {
	NSString *information;

}

-(id) initWithFrame: (CGRect) frame information: (NSString *) i;

@property (nonatomic, copy) IBOutlet NSString *information;
@property (nonatomic, copy) IBOutlet NSString *building_pictures;
@end
