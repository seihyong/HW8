    //
//  BuildingController.m
//  NavCon_HW8
//
//  Created by SEI-HYONG PARK on 7/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BuildingController.h"
#import "NavCon_HW8AppDelegate.h"
#import "BuildingView.h"
#import	"InfoController.h"

@implementation BuildingController

//Called by the nextLevel methos of class BuildingView

-(void) nextBuilding{
	UIApplication *a = [UIApplication sharedApplication];
	NavCon_HW8AppDelegate *d = a.delegate;
	[d nextBuilding];
}

-(id) initWithTitle: (NSString *) title northernNeighbor: (BOOL) b{
	self = [super initWithNibName:nil bundle:nil];
	if (self != nil){
		//Custom initialization
		self.title = title;
		//If not at last building then calls nextBuilding to create new controller
		if (b){
			self.navigationItem.rightBarButtonItem=
			[[UIBarButtonItem alloc] initWithTitle: @"go north"
											 style: UIBarButtonItemStyleBordered
											target: self
											action: @selector(nextBuilding)
			 ];
		}
	}
	return self;
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void) loadView {
	CGRect f = [UIScreen mainScreen].applicationFrame;
	self.view = [[BuildingView alloc] initWithFrame: f controller: self];
}

-(void) moreInfo{
	[[UIApplication sharedApplication].delegate	moreInfo: self];
}
					
/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return YES;
	//return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[self.view release];
    [super dealloc];
}


@end
