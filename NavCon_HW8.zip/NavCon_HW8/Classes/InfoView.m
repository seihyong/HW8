//
//  InfoView.m
//  NavCon_HW8
//
//  Created by SEI-HYONG PARK on 7/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "InfoView.h"


@implementation InfoView
@synthesize information;
@synthesize building_pictures;

//- (id)initWithFrame:(CGRect)frame information: (NSString *) i{
- (id)initWithFrame:(CGRect)frame information: (NSString *) i building_pictures: (NSString *) bp{    
    self = [super initWithFrame:frame];
    if (self) {
//		self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"skyline.jpg"]];
		self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed: bp]];
		self.information = i;
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
	CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 1.0, 0.0, 1.0, 1.0);
    UIFont *f = [UIFont boldSystemFontOfSize: 12];
	[self.information drawAtPoint: CGPointZero withFont: f];
}


- (void)dealloc {
	[information release];
	[building_pictures release];
    [super dealloc];
}


@end
