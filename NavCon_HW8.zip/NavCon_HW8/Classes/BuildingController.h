//
//  BuildingController.h
//  NavCon_HW8
//
//  Created by SEI-HYONG PARK on 7/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BuildingController : UIViewController {

}

-(id) initWithTitle: (NSString *) title northernNeighbor: (BOOL) b;
-(void) nextBuilding;
-(void) moreInfo;

@end
