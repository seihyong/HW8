    //
//  InfoController.m
//  NavCon_HW8
//
//  Created by SEI-HYONG PARK on 7/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "InfoController.h"
#import	"InfoView.h"

@implementation InfoController
@synthesize information;
@synthesize building_pictures;

-(void) back{
	[self.parentViewController.parentViewController
	 dismissModalViewControllerAnimated: YES];
}

//-(id) initWithTitle: (NSString *) title information: (NSString *) i {
-(id) initWithTitle: (NSString *) title information: (NSString *) i building_pictures: (NSString *) bp{
	self = [super initWithNibName: nil bundle: nil];
	if (self != nil){
		self.title = title;
		
		self.navigationItem.rightBarButtonItem=
		[[UIBarButtonItem alloc] initWithTitle: @"go back"
										 style: UIBarButtonItemStylePlain
										target: self
										action: @selector(back)
		 ];
		information = i;
		building_pictures = bp;
	}
	return self;
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	CGRect f = [UIScreen mainScreen].applicationFrame;
	//self.view = [[InfoView alloc] initWithFrame: f information: information];
	self.view = [[InfoView alloc] initWithFrame: f information: information building_pictures: building_pictures];
}

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return YES;
	//return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[self.view release];
	[information release];
    [super dealloc];
}


@end
